DelayLens real TfL data handoff. Start with quality.json, then segments.csv or snapshot.json.
All segment times are inferred, not measured actual arrivals. audit_examples.json links events to raw evidence.
raw/polls.jsonl.gz contains the canonical full captured HTTP payloads through this generation.
MANIFEST.json contains SHA256 checksums. No model, API or UI success is asserted.
